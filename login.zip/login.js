/*global $, document, window, setTimeout, navigator, console, location*/

// --- Firebase Imports & Initialization ---
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence 
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-analytics.js";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC50co9tqbh8ToywARBB2eboIrrfqyHoBk",
  authDomain: "travelx-a0123.firebaseapp.com",
  projectId: "travelx-a0123",
  storageBucket: "travelx-a0123.appspot.com",
  messagingSenderId: "667991544321",
  appId: "1:667991544321:web:2b7b49c02c32bcbc81e600",
  measurementId: "G-N3R2MD553D"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const analytics = getAnalytics(app);

// Set auth persistence to local so the user remains signed in
setPersistence(auth, browserLocalPersistence).catch((error) => {
  console.error("Error setting persistence:", error);
});

// --- jQuery Code for UI, Validation, and Form Switch ---
$(document).ready(function () {
    'use strict';

    var usernameError = true,
        emailError    = true,
        passwordError = true,
        passConfirm   = true;

    // Detect Firefox for CSS purposes
    if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
        $('.form form label').addClass('fontSwitch');
    }

    // Label effect on focus
    $('input').focus(function () {
        $(this).siblings('label').addClass('active');
    });

    // Form validation on blur
    $('input').blur(function () {
        // Validate Full Name
        if ($(this).hasClass('name')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('Please type your full name')
                  .fadeIn().parent('.form-group').addClass('hasError');
                usernameError = true;
            } else if ($(this).val().length > 1 && $(this).val().length <= 6) {
                $(this).siblings('span.error').text('Please type at least 6 characters')
                  .fadeIn().parent('.form-group').addClass('hasError');
                usernameError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut()
                  .parent('.form-group').removeClass('hasError');
                usernameError = false;
            }
        }
        // Validate Email
        if ($(this).hasClass('email')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('Please type your email address')
                  .fadeIn().parent('.form-group').addClass('hasError');
                emailError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut()
                  .parent('.form-group').removeClass('hasError');
                emailError = false;
            }
        }
        // Validate Password
        if ($(this).hasClass('pass')) {
            if ($(this).val().length < 8) {
                $(this).siblings('span.error').text('Please type at least 8 characters')
                  .fadeIn().parent('.form-group').addClass('hasError');
                passwordError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut()
                  .parent('.form-group').removeClass('hasError');
                passwordError = false;
            }
        }
        // Validate Password Confirmation
        if ($('.pass').val() !== $('.passConfirm').val()) {
            $('.passConfirm').siblings('.error').text('Passwords don\'t match')
              .fadeIn().parent('.form-group').addClass('hasError');
            passConfirm = true;
        } else {
            $('.passConfirm').siblings('.error').text('')
              .fadeOut().parent('.form-group').removeClass('hasError');
            passConfirm = false;
        }
        // Label effect on blur
        if ($(this).val().length > 0) {
            $(this).siblings('label').addClass('active');
        } else {
            $(this).siblings('label').removeClass('active');
        }
    });

    // Toggle between login and signup forms
    $('a.switch').click(function (e) {
        e.preventDefault();
        $(this).toggleClass('active');
        if ($(this).hasClass('active')) {
            $(this).parents('.form-peice').addClass('switched')
              .siblings('.form-peice').removeClass('switched');
        } else {
            $(this).parents('.form-peice').removeClass('switched')
              .siblings('.form-peice').addClass('switched');
        }
    });

    // --- Firebase Signup ---
    // Ensure your signup form uses the class "signup-form"
    $('form.signup-form').submit(function (event) {
        event.preventDefault();
        // Trigger blur on all inputs to run validation first
        $('.name, .email, .pass, .passConfirm').blur();
        if (usernameError || emailError || passwordError || passConfirm) {
            return;
        } else {
            var emailVal = $('.signup-form .email').val();
            var passwordVal = $('.signup-form .pass').val();
            createUserWithEmailAndPassword(auth, emailVal, passwordVal)
              .then((userCredential) => {
                  // Optionally, you can show UI animations here before redirecting
                  // Redirect to main page (index.html) after successful signup
                  location.href = "index.html";
              })
              .catch((error) => {
                  alert(error.message);
              });
        }
    });

    // --- Firebase Login ---
    // Ensure your login form uses the class "login-form"
    $('form.login-form').submit(function (event) {
        event.preventDefault();
        var emailVal = $('.login-form #loginemail').val();
        var passwordVal = $('.login-form #loginPassword').val();
        signInWithEmailAndPassword(auth, emailVal, passwordVal)
          .then((userCredential) => {
              // Redirect to main page (index.html) after successful login
              location.href = "index.html";
          })
          .catch((error) => {
              alert(error.message);
          });
    });

    // --- Firebase Logout ---
    // When the "profile" link is clicked, sign out the user
    $('a.profile').on('click', function (e) {
        e.preventDefault();
        signOut(auth)
          .then(() => {
              alert("You have logged out.");
              location.reload(true);
          })
          .catch((error) => {
              alert(error.message);
          });
    });

    // --- Auth State Listener (Optional) ---
    // If the user is already logged in when on the login page, redirect them immediately
    onAuthStateChanged(auth, (user) => {
        if (user) {
            location.href = "../index.html";
        }
    });
});
document.addEventListener("DOMContentLoaded", function () {
    const phoneInput = document.getElementById("phone");

    phoneInput.addEventListener("input", function () {
        this.value = this.value.replace(/\D/g, ""); 
        if (this.value.length > 10) {
            this.value = this.value.slice(0, 10);
        }
    });

    document.querySelector(".signup-form").addEventListener("submit", function (event) {
        if (phoneInput.value.length > 0 && phoneInput.value.length !== 10) {
            alert("Phone number must be exactly 10 digits.");
            event.preventDefault();
        }
    });
});